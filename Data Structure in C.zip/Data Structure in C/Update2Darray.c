#include <stdio.h>
int main()
{
    int b[2][3];
    int i,j,num;
    printf("Enter elements into 2-D array: ");
    for(i=0; i<2; i++)
    {
        for(j=0; j<3; j++)
        {
            scanf("%d" , &b[i][j]);
        }
    }
    printf("Enter the value of row and column number :");
    scanf("%d  %d", &i,&j);
    printf("Enter the number you want to update with: ");
    scanf("%d" , &num);
    b[i][j]=num;
    for(i=0; i<2; i++)
    {
        for(j=0; j<3; j++)
        {
            printf("\t%d" , b[i][j]);
        }
        printf("\n");
    }
    return 0;
}
