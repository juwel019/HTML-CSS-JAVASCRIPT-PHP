#include <iostream>
using namespace std;

string deccrypt(string text, int s)
{
    string result = "";
    for (int i=0;i<text.length();i++)
    {
        if (isupper(text[i]))
            result += char(int(text[i]+s-65)%26 +65);
    else
        result += char(int(text[i]+s-97)%26 +97);
    }
    return result;
}

int main()
{
    string text="Juwel";
    int s = -3;
    cout << "Text : " << text;
    cout << "\nShift: " << s;
    cout << "\nCaesar Cipher decryption: " << deccrypt(text, s);
    return 0;
}
