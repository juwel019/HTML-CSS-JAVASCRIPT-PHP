#include<stdio.h>
#include<string.h>
int main()
{

char plaintxt[100]=
{'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};

char ciphrtxt[100]=
{'Z','Y','X','W','V','U','T','S','R','Q','P','O','N','M','L','K','J','I','H','G','F','E','D','C','B','A',
'z','y','x','w','v','u','t','s','r','q','p','o','n','m','l','k','j','i','h','g','f','e','d','c','b','a'};

    char plain[50],cipher[50];

    int i,j;

    printf("\n enter the plain text:");

    gets(plain);

    for(i=0;i<strlen(plain);i++)

    {
      for(j=0;j<52;j++)

        {
             if(plaintxt[j]==plain[i])

            {
            cipher[i]=ciphrtxt[j];
            }
        }
    }

    printf("\n cipher text is: %s",cipher);


}
