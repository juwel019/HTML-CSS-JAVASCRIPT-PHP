#include<iostream>
#include<string.h>
using namespace std;

int main() {
   cout<<"Enter the message:\n";
   char msg[100],copy[100];
   cin.getline(msg,100); //enter Hello World

   int i, j, length,key;
   cout << "Enter shifted number: ";
    cin>>key;
   length = strlen(msg);

      char ch;
      for(int i = 0; i<length; ++i) {
         ch = msg[i];

         int chi=(int)ch;
         if (chi >= 97 && chi <= 122){
            chi = chi + key;
            if (chi > 122) {
               chi -=26 ;
            }
            msg[i] = (char)chi;
         }

         else if (chi >= 65 && chi <= 90){
            chi = chi + key;
            if (chi > 90){
               chi -= 26;
            }
            msg[i] = (char)chi;
         }
      }
      cout<<"Encrypted message:"<< msg;
   }
