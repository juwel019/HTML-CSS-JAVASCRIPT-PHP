# school-management-web-application
School management web application using php,msqli


Features:                                                                                                                                 
  1.Multiple user                                                                                                                         
  2.Add student                                                                                                                           
  3.delete student                                                                                                                        
  4.update utudent profile                                                                                                      
  5.marks entry                                                             
  6.update marks                                                                  
  7.Search result                                                               
  8.Search student                                                                                                                         
  9.Data download in pdf & excel format                                                                                                   
  10.Upload Student data from excel file                                                                                                  
  11.Update Data from excel file.                                                                                                     
  12.Dynamicly load subject from database using ajax method                                                                              
  13.Subject load dynamicly                                                                                                               
  
  
  
  
Installation:                                                                                                                             
  1.Create a database 'school'                                                                                                             
  2.Open \core\init.php & replace info with urs.       
  
Live: http://schoolz.likesyou.org                                                                                                         
LOGIN ACCOUNT                                                                                                                           
    Email: admin@gmail.com                                                                                                                 
    Password: root
