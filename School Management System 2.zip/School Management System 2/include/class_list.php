<option value=" ">-Class-</option>
<option value="Eleven">Eleven</option>
<option  value="Twelve">Twelve</option>
<option  value="Hons.">Hons.</option>
<option  value="Hons. Prof.">Hons. Prof.</option>
<option  value="Degree Pass">Degree Pass</option>
<option  value="BM">BM</option>


