<?php

if (isset($_POST[])) {

	echo "string";
}

wp_send_json( $response );


?>