<div class="col-md-5">
  <?php include('holidayform.php'); ?>
</div>
<!-- /.col -->
<div class="col-md-7">
  <?php include('holidayslist.php'); ?>
</div>
<!-- /.col -->
