import java.io.*;
import java.net.InetSocketAddress;
import com.sun.net.httpserver.*;

public class HTTP
{
	public static void main(String args[]) throws Exception
	{
		HttpServer ob = HttpServer.create(new InetSocketAddress(8000),0);
		ob.createContext("/name",new nameHandler());
		ob.createContext("/id",new nameHandler1());
		ob.setExecutor(null);
		ob.start();
	}
	
	static class nameHandler implements HttpHandler
	{
		public void handle(HttpExchange t) throws IOException
		{
			byte [] res = "<!DOCTYPE html><html><head><style>body {background-color: powderblue;}h1   {color: blue;}p    {color: red;}</style></head><body><h1>Juwel Rana</h1><p>Welcome</p></body></html>".getBytes();
			t.sendResponseHeaders(200,res.length);
			OutputStream os = t.getResponseBody();
			os.write(res);
			os.close();
		}
	}
	static class nameHandler1 implements HttpHandler
	{
		public void handle(HttpExchange t) throws IOException
		{
			byte [] res = "<!DOCTYPE html><html><head><style>body {background-color: powderblue;}h1 {color: blue;}p {color: red;}</style></head><body><h1>ID.171311019</h1><p>welcome</p></body></html>".getBytes();
			t.sendResponseHeaders(200,res.length);
			OutputStream os = t.getResponseBody();
			os.write(res);
			os.close();
		}
	}
}