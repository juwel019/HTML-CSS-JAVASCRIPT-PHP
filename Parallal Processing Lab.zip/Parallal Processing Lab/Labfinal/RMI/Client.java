import java.rmi.registry.*;
import java.util.*;

public class Client{
	
	public static void main(String args[])throws Exception
	{
		Registry reg=LocateRegistry.getRegistry();
		ImplInterface robj=(ImplInterface)reg.lookup("RMIservice");
		scanner sc=new scanner(system.in);
                System.out.println("Enter the operation: ");
                char ch=
                System.out.println("Enter 1st operation: ");
                char ch=
                
	}
}
