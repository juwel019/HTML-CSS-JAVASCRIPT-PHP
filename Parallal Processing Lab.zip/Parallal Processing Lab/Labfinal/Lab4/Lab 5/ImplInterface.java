import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ImplInterface extends Remote{
	 void printMsg() throws RemoteException;
	
}