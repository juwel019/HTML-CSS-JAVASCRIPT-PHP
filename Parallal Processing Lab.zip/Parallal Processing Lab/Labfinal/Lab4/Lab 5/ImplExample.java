public class ImplExample implements ImplInterface{
	public void printMsg()
	{
		System.out.println("RMI Worked");
	}
}