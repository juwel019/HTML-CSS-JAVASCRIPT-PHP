import java.rmi.registry.*;

public class Client{
	
	public static void main(String args[])throws Exception
	{
		Registry reg=LocateRegistry.getRegistry();
		ImplInterface robj=(ImplInterface)reg.lookup("RMIservice");
		robj.printMsg();
	}
}
