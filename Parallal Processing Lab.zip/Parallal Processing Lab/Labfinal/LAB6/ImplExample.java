
public class ImplExample implements ImplInterface{
	public void f1(){
		System.out.println("F1 is running");
	}
	public void f2(){
		System.out.println("F2 is running");
	}
	public void f3(){
		System.out.println("F3 is running");
	}
}