import java.rmi.Remote;
import java.rmi.RemoteException;
public interface ImplInterface extends Remote{
	void f1() throws RemoteException;
	void f2() throws RemoteException;
        
}