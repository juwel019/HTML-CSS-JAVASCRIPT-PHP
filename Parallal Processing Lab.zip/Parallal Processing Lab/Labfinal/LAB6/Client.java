import java.rmi.registry.*;

public class Client{
	public static void main(String args[]) throws Exception{
		Registry reg=LocateRegistry.getRegistry();
		ImplInterface robj=(ImplInterface)reg.lookup("RMIservice");
		robj.f1();
		
		Registry reg2=LocateRegistry.getRegistry();
		ImplInterface robj2=(ImplInterface)reg2.lookup("RMIservice");
		robj2.f2();
                
               Registry reg3=LocateRegistry.getRegistry();
		ImplInterface robj3=(ImplInterface)reg3.lookup("RMIservice");
		robj3.f3();  
		
	}
}