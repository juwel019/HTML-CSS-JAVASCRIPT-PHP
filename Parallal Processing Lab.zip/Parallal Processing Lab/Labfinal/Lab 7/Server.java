import java.rmi.registry.*;
import java.rmi.server.UnicastRemoteObject;

public class Server extends ImplExample{
	
	public static void main(String args[]) throws Exception
	{
		ImplExample obj=new ImplExample();
		ImplInterface stub=(ImplInterface)UnicastRemoteObject.exportObject(obj,0);
		Registry reg=LocateRegistry.getRegistry();
		reg.bind("RMIservice",stub);
	}
} 
