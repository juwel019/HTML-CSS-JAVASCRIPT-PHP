import java.rmi.registry.*;
import java.util.*;
public class Client{
	static double c;
	public static void main(String args[])throws Exception
	{
		Registry reg=LocateRegistry.getRegistry();
		ImplInterface robj=(ImplInterface)reg.lookup("RMIservice");
		Scanner sc= new Scanner(System.in); 
		System.out.print("Enter the operation: ");
		char ch= sc.next().charAt(0);
		System.out.print("Enter 1st operant: ");
		double a= sc.nextDouble();
		System.out.print("Enter 2nd operant: ");
		double b= sc.nextDouble();
		if(ch=='+')
		{
			c=robj.add(a,b);
			System.out.print("Result:"+c);
		}
		if(ch=='-')
		{
			c=robj.sub(a,b);
			System.out.print("Result:"+c);
		}
	}
}
