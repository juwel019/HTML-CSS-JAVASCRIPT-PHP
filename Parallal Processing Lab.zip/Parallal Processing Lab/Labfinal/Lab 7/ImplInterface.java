import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ImplInterface extends Remote{
	double add(double a,double b) throws RemoteException;
	double sub(double a,double b) throws RemoteException;
}
