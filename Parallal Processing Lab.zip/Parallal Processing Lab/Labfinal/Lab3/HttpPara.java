import java.io.*;
import java.net.InetSocketAddress;
import com.sun.net.httpserver.*;
public class HttpPara{
static int a=0;
static int b=0;
static int c=0;

static class aHandler implements HttpHandler{
public void handle(HttpExchange he) throws IOException
{

String r=he.getRequestURI().getQuery();
a= Integer.parseInt(r);
he.sendResponseHeaders(200,r.length());
OutputStream os = he.getResponseBody();
os.write(r.getBytes());
os.close();
}
}
static class bHandler implements HttpHandler{
public void handle(HttpExchange he) throws IOException
{
String r=he.getRequestURI().getQuery();
b= Integer.parseInt(r);
he.sendResponseHeaders(200,r.length());
OutputStream os = he.getResponseBody();
os.write(r.getBytes());
os.close();
}
}
static class cHandler implements HttpHandler{
public void handle(HttpExchange he) throws IOException
{
if(a==0){
String r="Set the value of a";
he.sendResponseHeaders(200,r.length());
OutputStream os = he.getResponseBody();
os.write(r.getBytes());
os.close();
}
if(b==0){
String r="Set the value of b";
he.sendResponseHeaders(200,r.length());
OutputStream os = he.getResponseBody();
os.write(r.getBytes());
os.close();
}
else{
c=a+b;
String r=Integer.toString(c);
he.sendResponseHeaders(200,r.length());
OutputStream os = he.getResponseBody();
os.write(r.getBytes());
os.close();
}
}
}
public static void main(String args[]) throws Exception{
HttpServer s= HttpServer.create(new InetSocketAddress(8000),0);
s.createContext("/a", new aHandler());
s.createContext("/b",new bHandler());
s.createContext("/c",new cHandler());
s.setExecutor(null);
s.start();
System.out.println("Server is Running");
}
}