import java.net.*;
import java.io.*;
public class SocServer{
public static void main(String args[]) throws Exception
{
ServerSocket ss=new ServerSocket(8000);
Socket s=ss.accept();
DataInputStream dis=new DataInputStream(s.getInputStream());
String st=(String)dis.readUTF();
System.out.println("Message from client is "+st);
}
}