import java.net.*;
import java.io.*;
public class SocClint{
public static void main(String args[]) throws Exception
{
 Socket s=new Socket("localhost",8000);
DataOutputStream dout=new DataOutputStream(s.getOutputStream());
dout.writeUTF("This is msg");
dout.flush();
}
}